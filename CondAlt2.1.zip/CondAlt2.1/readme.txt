The file 'CondAlt2.1zip' contains a single directory 'CondAlt2.1',
which contains a copy of this 'readme.txt'.

Please see the URL
https://go.usa.gov/xRu79 
for further information.
